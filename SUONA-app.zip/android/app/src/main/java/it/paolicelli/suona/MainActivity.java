package it.paolicelli.suona;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView wv;
    private ValueCallback<Uri[]> fileCb;
    private boolean ready = false;
    private Intent pending;
    private final ArrayList<Uri> saved = new ArrayList<>();
    private static final int PICK = 7;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.addJavascriptInterface(new Bridge(), "AndroidApp");
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(Intent.createChooser(i, "Apri spartito"), PICK); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                ready = true;
                if (pending != null) { Intent i = pending; pending = null; handle(i); }
            }
        });
        pending = getIntent();
        wv.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (ready) handle(i); else pending = i;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == PICK && fileCb != null) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) {
                    out = new Uri[cd.getItemCount()];
                    for (int k = 0; k < cd.getItemCount(); k++) out[k] = cd.getItemAt(k).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            fileCb.onReceiveValue(out);
            fileCb = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        wv.evaluateJavascript("(function(){var o=document.querySelector('.modal.open');if(o){o.classList.remove('open');return 1}var f=document.querySelector('.fs');if(f){document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));return 1}return 0})()",
            r -> { if (!"1".equals(r)) MainActivity.super.onBackPressed(); });
    }

    /* file o link condivisi con l'app ("Apri con…" / "Condividi") */
    private void handle(Intent i) {
        if (i == null) return;
        String a = i.getAction();
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(a)) u = i.getData();
        else if (Intent.ACTION_SEND.equals(a)) {
            u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u == null) {
                String t = i.getStringExtra(Intent.EXTRA_TEXT);
                if (t != null) js("window.openLinkFromAndroid&&openLinkFromAndroid(" + JSONObject.quote(t) + ")");
                return;
            }
        }
        if (u == null) return;
        final Uri fu = u;
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(fu);
                byte[] data = readAll(in);
                String name = nameOf(fu), mime = getContentResolver().getType(fu);
                String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                js("window.openFromAndroid&&openFromAndroid(" + JSONObject.quote(b64) + "," + JSONObject.quote(mime == null ? "" : mime) + "," + JSONObject.quote(name) + ")");
            } catch (Exception e) { toast("Non riesco ad aprire il file"); }
        }).start();
    }

    private String nameOf(Uri u) {
        String n = "spartito";
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (k >= 0) n = c.getString(k); }
        } catch (Exception e) { String p = u.getLastPathSegment(); if (p != null) n = p; }
        return n;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[65536]; int r;
        while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
        in.close();
        return o.toByteArray();
    }

    private void js(String code) { runOnUiThread(() -> wv.evaluateJavascript(code, null)); }
    private void toast(String t) { runOnUiThread(() -> Toast.makeText(this, t, Toast.LENGTH_LONG).show()); }

    private Uri saveBytes(byte[] data, String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SUONA");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(data); }
            return u;
        }
        File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SUONA");
        d.mkdirs();
        File f = new File(d, name);
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
        return Uri.fromFile(f);
    }

    class Bridge {
        /* scarica da internet senza i blocchi del browser (Mega, Drive, Dropbox…) */
        @JavascriptInterface
        public void request(String id, String method, String url, String body) {
            new Thread(() -> {
                try {
                    String u = url; HttpURLConnection c = null; int st = 0;
                    for (int hop = 0; hop < 8; hop++) {
                        c = (HttpURLConnection) new URL(u).openConnection();
                        c.setInstanceFollowRedirects(false);
                        c.setRequestMethod(method);
                        c.setConnectTimeout(20000); c.setReadTimeout(60000);
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SUONA");
                        if (body != null && "POST".equals(method)) {
                            c.setDoOutput(true);
                            try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes("UTF-8")); }
                        }
                        st = c.getResponseCode();
                        if (st >= 300 && st < 400 && c.getHeaderField("Location") != null) { u = new URL(new URL(u), c.getHeaderField("Location")).toString(); continue; }
                        break;
                    }
                    InputStream in = st >= 400 ? c.getErrorStream() : c.getInputStream();
                    byte[] data = in == null ? new byte[0] : readAll(in);
                    String cd = c.getHeaderField("Content-Disposition"), name = "";
                    if (cd != null) { java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\*?=(?:UTF-8'')?\"?([^\";]+)").matcher(cd); if (m.find()) name = java.net.URLDecoder.decode(m.group(1), "UTF-8"); }
                    String type = c.getContentType();
                    js("window._netDone(" + JSONObject.quote(id) + "," + st + "," + JSONObject.quote(Base64.encodeToString(data, Base64.NO_WRAP)) + "," + JSONObject.quote(type == null ? "" : type) + "," + JSONObject.quote(name) + "," + JSONObject.quote(u) + ")");
                } catch (Exception e) {
                    js("window._netDone(" + JSONObject.quote(id) + ",0,null," + JSONObject.quote("rete non disponibile") + ",'','')");
                }
            }).start();
        }

        @JavascriptInterface
        public void saveFile(String b64, String name, String mime) {
            try { saved.add(saveBytes(Base64.decode(b64, Base64.DEFAULT), name, mime == null || mime.isEmpty() ? "application/octet-stream" : mime)); }
            catch (Exception e) { toast("Non riesco a salvare: " + e.getMessage()); }
        }

        @JavascriptInterface
        public void savePdf(String b64, String name) { saveFile(b64, name, "application/pdf"); shareSaved("application/pdf"); }

        @JavascriptInterface
        public void shareSaved(String mime) {
            if (saved.isEmpty()) return;
            ArrayList<Uri> l = new ArrayList<>(saved); saved.clear();
            toast("Salvato in Download › SUONA");
            if (Build.VERSION.SDK_INT < 29) return;
            Intent i;
            if (l.size() == 1) { i = new Intent(Intent.ACTION_SEND); i.putExtra(Intent.EXTRA_STREAM, l.get(0)); }
            else { i = new Intent(Intent.ACTION_SEND_MULTIPLE); i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, l); }
            i.setType(mime == null || mime.isEmpty() ? "*/*" : mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Condividi");
            runOnUiThread(() -> { try { startActivity(ch); } catch (Exception e) { } });
        }

        @JavascriptInterface
        public void setLandscape(boolean on) {
            runOnUiThread(() -> setRequestedOrientation(on ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
        }
    }
}
