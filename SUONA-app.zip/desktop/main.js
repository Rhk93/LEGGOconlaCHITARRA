const { app, BrowserWindow, shell, session } = require('electron');
const path = require('path');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
function apri() {
  const w = new BrowserWindow({
    width: 1280, height: 900, minWidth: 420, minHeight: 500, backgroundColor: '#f1f3f5', autoHideMenuBar: true,
    title: 'SUONA Spartito', icon: path.join(__dirname, 'www', 'icon.png'),
    webPreferences: { webSecurity: false, contextIsolation: true }
  });
  w.loadFile(path.join(__dirname, 'www', 'index.html'));
  w.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}
app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  apri();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) apri(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
